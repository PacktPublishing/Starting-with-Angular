# Starting with Angular
### Updated for version 4.3

This is project code for the "Starting with Angular" course.  The course has been updated for working with Angular version 4.3.

This project was generated using the Cloud 9 IDE and is configured to run in that environment.  To build/run this project locally, remove the modifications (--host 0.0.0.0 --port 8080 --public $C9_HOSTNAME) from the package.json "start" script. 
