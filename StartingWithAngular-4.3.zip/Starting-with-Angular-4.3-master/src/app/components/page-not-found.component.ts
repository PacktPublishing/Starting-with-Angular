import { Component } from '@angular/core';

@Component({
  template: '<h2>Ooops... Page Not Found</h2>'
})

export class PageNotFoundComponent {}